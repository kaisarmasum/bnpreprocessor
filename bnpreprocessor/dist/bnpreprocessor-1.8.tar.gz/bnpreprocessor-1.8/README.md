﻿Bengali Text Preprocessor
===================

Installation
-------------

    pip install bn_preprocessor==1.8

Quick Start
-------------
After installation, using bengali preprocessor should be fairly straight forward:

**Text Preprocess**

    from bnpreprocessor import preprocessor

    text = preprocessor("আগে যখন আমি ফুটবল বুঝতাম না ও দেখতাম না তখন ভাবতাম মেসিই সেরা। তারপর যখন আমি ফুটবল বোঝা ও দেখা শুরু করলাম তখন উপলব্ধি করলাম যে,আগে আমি ভুল ছিলাম না।")
    print(text)
  
    
